import streamlit as st
import requests

st.set_page_config(
    page_title="Wine Quality Predictor",
    page_icon="🍷",
    layout="wide"
)

# -----------------------------
# HEADER
# -----------------------------
st.title("🍷 Wine Quality Prediction System")
st.write(
    "A Machine Learning application that predicts wine quality "
    "based on its physicochemical properties."
)

st.divider()

# -----------------------------
# MODEL INFORMATION
# -----------------------------
st.subheader("🤖 Model Information")

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Model", "Random Forest")

with col2:
    st.metric("Accuracy", "88.44%")

with col3:
    st.metric("Precision", "84.56%")

with col4:
    st.metric("F1 Score", "86.40%")

st.divider()

# -----------------------------
# INPUT SECTION
# -----------------------------
st.subheader("🧪 Enter Wine Properties")

col1, col2 = st.columns(2)

with col1:
    fixed_acidity = st.number_input(
        "Fixed Acidity", value=7.4
    )

    volatile_acidity = st.number_input(
        "Volatile Acidity", value=0.70
    )

    citric_acid = st.number_input(
        "Citric Acid", value=0.00
    )

    residual_sugar = st.number_input(
        "Residual Sugar", value=1.9
    )

    chlorides = st.number_input(
        "Chlorides", value=0.076
    )

    free_sulfur_dioxide = st.number_input(
        "Free Sulfur Dioxide", value=11.0
    )

with col2:
    total_sulfur_dioxide = st.number_input(
        "Total Sulfur Dioxide", value=34.0
    )

    density = st.number_input(
        "Density", value=0.9978
    )

    pH = st.number_input(
        "pH", value=3.51
    )

    sulphates = st.number_input(
        "Sulphates", value=0.56
    )

    alcohol = st.number_input(
        "Alcohol (%)", value=9.4
    )

st.divider()

# -----------------------------
# PREDICTION
# -----------------------------
if st.button("🍷 Predict Wine Quality", use_container_width=True):

    data = {
        "fixed_acidity": fixed_acidity,
        "volatile_acidity": volatile_acidity,
        "citric_acid": citric_acid,
        "residual_sugar": residual_sugar,
        "chlorides": chlorides,
        "free_sulfur_dioxide": free_sulfur_dioxide,
        "total_sulfur_dioxide": total_sulfur_dioxide,
        "density": density,
        "pH": pH,
        "sulphates": sulphates,
        "alcohol": alcohol
    }

    try:
        response = requests.post(
            "http://127.0.0.1:8004/predict",
            json=data
        )

        if response.status_code == 200:

            result = response.json()["quality_category"]

            st.subheader("Prediction Result")

            if result == "Low":
                st.warning("🟠 LOW QUALITY")

            elif result == "Average":
                st.info("🔵 AVERAGE QUALITY")

            elif result == "High":
                st.success("🟢 HIGH QUALITY")

            else:
                st.write(
                    f"Predicted Wine Quality: {result}"
                )

        else:
            st.error(
                f"Prediction failed. Server returned "
                f"status code {response.status_code}"
            )

    except requests.exceptions.ConnectionError:
        st.error(
            "Cannot connect to the FastAPI server. "
            "Please make sure FastAPI is running on port 8004."
        )

# -----------------------------
# FOOTER
# -----------------------------
st.divider()

st.caption(
    "Wine Quality Prediction System | "
    "Powered by Machine Learning and Random Forest"
)